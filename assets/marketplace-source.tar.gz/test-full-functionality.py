#!/usr/bin/env python3
import requests
import time

def test_main_pages():
    """Test main pages accessibility"""
    print("🏠 Testing Main Pages")
    base_url = "http://localhost"
    
    pages = [
        ("/", "Homepage"),
        ("/login/", "Login Page"),
        ("/signup/", "Signup Page"),
        ("/category.php", "Category Page"),
        ("/shop-details.php", "Shop Details"),
        ("/shoping-cart.php", "Shopping Cart")
    ]
    
    accessible_pages = 0
    for path, name in pages:
        try:
            response = requests.get(f"{base_url}{path}", timeout=10)
            if response.status_code == 200:
                print(f"   ✅ {name}: OK")
                accessible_pages += 1
            else:
                print(f"   ❌ {name}: {response.status_code}")
        except Exception as e:
            print(f"   ❌ {name}: Error - {str(e)}")
    
    print(f"   📊 Accessible pages: {accessible_pages}/{len(pages)}")
    return accessible_pages == len(pages)

def test_admin_access():
    """Test admin panel access after login"""
    print("\n👑 Testing Admin Access")
    session = requests.Session()
    base_url = "http://localhost"
    
    # Login as admin
    login_data = {
        'username': 'serein',
        'password': 'Fpt1409!@',
        'submit': 'Login'
    }
    
    try:
        login_response = session.post(f"{base_url}/login/", data=login_data, allow_redirects=True)
        if login_response.status_code == 200:
            print("   ✅ Admin login successful")
            
            # Test admin pages
            admin_pages = [
                ("/admin/", "Admin Dashboard"),
                ("/admin/users.php", "User Management")
            ]
            
            admin_accessible = 0
            for path, name in admin_pages:
                try:
                    response = session.get(f"{base_url}{path}", timeout=10)
                    if response.status_code == 200:
                        print(f"   ✅ {name}: OK")
                        admin_accessible += 1
                    else:
                        print(f"   ❌ {name}: {response.status_code}")
                except Exception as e:
                    print(f"   ❌ {name}: Error - {str(e)}")
            
            print(f"   📊 Admin pages accessible: {admin_accessible}/{len(admin_pages)}")
            return admin_accessible > 0
        else:
            print("   ❌ Admin login failed")
            return False
    except Exception as e:
        print(f"   ❌ Admin test error: {str(e)}")
        return False

def test_seller_access():
    """Test seller panel access after login"""
    print("\n🏪 Testing Seller Access")
    session = requests.Session()
    base_url = "http://localhost"
    
    # Login as seller
    login_data = {
        'username': 'seller',
        'password': 'Fpt1409!@',
        'submit': 'Login'
    }
    
    try:
        login_response = session.post(f"{base_url}/login/", data=login_data, allow_redirects=True)
        if login_response.status_code == 200:
            print("   ✅ Seller login successful")
            
            # Test seller pages
            seller_pages = [
                ("/seller/", "Seller Dashboard"),
                ("/seller/addproduct.php", "Add Product")
            ]
            
            seller_accessible = 0
            for path, name in seller_pages:
                try:
                    response = session.get(f"{base_url}{path}", timeout=10)
                    if response.status_code == 200:
                        print(f"   ✅ {name}: OK")
                        seller_accessible += 1
                    else:
                        print(f"   ❌ {name}: {response.status_code}")
                except Exception as e:
                    print(f"   ❌ {name}: Error - {str(e)}")
            
            print(f"   📊 Seller pages accessible: {seller_accessible}/{len(seller_pages)}")
            return seller_accessible > 0
        else:
            print("   ❌ Seller login failed")
            return False
    except Exception as e:
        print(f"   ❌ Seller test error: {str(e)}")
        return False

def test_user_access():
    """Test regular user access after login"""
    print("\n👤 Testing User Access")
    session = requests.Session()
    base_url = "http://localhost"
    
    # Login as user
    login_data = {
        'username': 'user',
        'password': 'Fpt1409!@',
        'submit': 'Login'
    }
    
    try:
        login_response = session.post(f"{base_url}/login/", data=login_data, allow_redirects=True)
        if login_response.status_code == 200:
            print("   ✅ User login successful")
            
            # Test user can access main pages
            response = session.get(f"{base_url}/", timeout=10)
            if response.status_code == 200:
                print("   ✅ User can access homepage")
                return True
            else:
                print(f"   ❌ User cannot access homepage: {response.status_code}")
                return False
        else:
            print("   ❌ User login failed")
            return False
    except Exception as e:
        print(f"   ❌ User test error: {str(e)}")
        return False

def test_database_connection():
    """Test database connection by checking if pages load properly"""
    print("\n🗄️ Testing Database Connection")
    base_url = "http://localhost"
    
    try:
        response = requests.get(f"{base_url}/", timeout=10)
        if response.status_code == 200:
            content = response.text.lower()
            # Check for database error indicators
            if "mysqli" in content or "database" in content or "connection failed" in content:
                print("   ❌ Database connection issues detected")
                return False
            else:
                print("   ✅ Database connection appears healthy")
                return True
        else:
            print(f"   ❌ Cannot test database: {response.status_code}")
            return False
    except Exception as e:
        print(f"   ❌ Database test error: {str(e)}")
        return False

def main():
    print("🧪 Full Functionality Test")
    print("=" * 50)
    
    tests = [
        ("Main Pages", test_main_pages),
        ("Database Connection", test_database_connection),
        ("Admin Access", test_admin_access),
        ("Seller Access", test_seller_access),
        ("User Access", test_user_access)
    ]
    
    passed_tests = 0
    total_tests = len(tests)
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            if result:
                passed_tests += 1
        except Exception as e:
            print(f"   ❌ {test_name} failed with error: {str(e)}")
        
        time.sleep(1)  # Small delay between tests
    
    print("\n" + "=" * 50)
    print("📊 FINAL RESULTS")
    print(f"Passed tests: {passed_tests}/{total_tests}")
    print(f"Failed tests: {total_tests - passed_tests}/{total_tests}")
    
    if passed_tests == total_tests:
        print("\n🎉 ALL FUNCTIONALITY TESTS PASSED!")
        print("✅ Website is fully functional on HTTP")
        return True
    elif passed_tests >= total_tests * 0.8:  # 80% pass rate
        print("\n⚠️ MOST FUNCTIONALITY TESTS PASSED")
        print("✅ Website is mostly functional with minor issues")
        return True
    else:
        print("\n❌ MULTIPLE FUNCTIONALITY ISSUES DETECTED")
        print("🔧 Website needs attention")
        return False

if __name__ == "__main__":
    success = main()
    print(f"\nOverall status: {'✅ FUNCTIONAL' if success else '❌ NEEDS WORK'}")