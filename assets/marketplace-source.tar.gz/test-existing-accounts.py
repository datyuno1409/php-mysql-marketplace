#!/usr/bin/env python3
import requests
import urllib3
import json
from urllib.parse import urljoin

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def test_login(base_url, username, password):
    """Test login functionality"""
    session = requests.Session()
    session.verify = False
    
    try:
        # Get login page first
        login_url = urljoin(base_url, '/login.php')
        print(f"  📄 Getting login page: {login_url}")
        
        response = session.get(login_url, timeout=10)
        print(f"  📊 Login page status: {response.status_code}")
        
        if response.status_code != 200:
            return False, f"Login page not accessible (status: {response.status_code})"
        
        # Check if it's actually a login page
        if 'login' not in response.text.lower() and 'email' not in response.text.lower():
            return False, "Page doesn't appear to be a login form"
        
        # Attempt login
        login_data = {
            'email': username,
            'password': password,
            'login': 'Login'
        }
        
        print(f"  🔐 Attempting login with {username}...")
        login_response = session.post(login_url, data=login_data, timeout=10, allow_redirects=True)
        
        print(f"  📊 Login response status: {login_response.status_code}")
        print(f"  🔗 Final URL: {login_response.url}")
        
        # Check for successful login indicators
        response_text = login_response.text.lower()
        
        # Success indicators
        success_indicators = [
            'dashboard', 'welcome', 'logout', 'profile', 
            'my account', 'user panel', 'admin panel'
        ]
        
        # Error indicators
        error_indicators = [
            'invalid', 'incorrect', 'wrong', 'failed', 
            'error', 'try again', 'login failed'
        ]
        
        has_success = any(indicator in response_text for indicator in success_indicators)
        has_error = any(indicator in response_text for indicator in error_indicators)
        
        # Check if redirected away from login page
        is_redirected = 'login.php' not in login_response.url
        
        if has_success or (is_redirected and not has_error):
            return True, "Login successful"
        elif has_error:
            return False, "Login failed - invalid credentials"
        else:
            return False, "Login status unclear - no clear success/error indicators"
            
    except requests.exceptions.Timeout:
        return False, "Request timeout"
    except requests.exceptions.ConnectionError:
        return False, "Connection error"
    except Exception as e:
        return False, f"Unexpected error: {str(e)}"

def test_website_accessibility(url):
    """Test if website is accessible"""
    try:
        response = requests.get(url, verify=False, timeout=10)
        return response.status_code, response.text[:500]
    except Exception as e:
        return None, str(e)

def main():
    print("🧪 Testing Existing Accounts on Marketplace")
    print("=" * 50)
    
    # Test URLs
    test_urls = [
        "https://vn-nextstep.cftenant.com",
        "http://vn-nextstep.cftenant.com", 
        "http://103.9.205.28"
    ]
    
    # Common test accounts (you may need to adjust these)
    test_accounts = [
        {"username": "admin@marketplace.com", "password": "admin123"},
        {"username": "test@test.com", "password": "test123"},
        {"username": "user@example.com", "password": "password"},
        {"username": "demo@demo.com", "password": "demo123"},
        {"username": "admin", "password": "admin"},
        {"username": "callmeserein@gmail.com", "password": "Next-Step@2310"}
    ]
    
    # First, test website accessibility
    print("\n🌐 Testing Website Accessibility:")
    print("-" * 30)
    
    accessible_urls = []
    
    for url in test_urls:
        print(f"\n🔍 Testing {url}...")
        status_code, content = test_website_accessibility(url)
        
        if status_code:
            print(f"  ✅ Status: {status_code}")
            if status_code == 200:
                accessible_urls.append(url)
                # Check content type
                if 'marketplace' in content.lower():
                    print(f"  📦 Marketplace content detected")
                elif 'nginx' in content.lower():
                    print(f"  🌐 Nginx default page detected")
                elif 'login' in content.lower():
                    print(f"  🔐 Login page detected")
                else:
                    print(f"  📄 Generic web content")
            else:
                print(f"  ⚠️ Non-200 status code")
        else:
            print(f"  ❌ Connection failed: {content}")
    
    if not accessible_urls:
        print("\n❌ No accessible URLs found. Cannot proceed with login tests.")
        return
    
    # Test login functionality
    print("\n🔐 Testing Login Functionality:")
    print("-" * 30)
    
    results = []
    
    for url in accessible_urls:
        print(f"\n🌐 Testing login on {url}:")
        
        for account in test_accounts:
            username = account['username']
            password = account['password']
            
            print(f"\n  👤 Testing {username}...")
            success, message = test_login(url, username, password)
            
            result = {
                'url': url,
                'username': username,
                'success': success,
                'message': message
            }
            results.append(result)
            
            if success:
                print(f"  ✅ {message}")
            else:
                print(f"  ❌ {message}")
    
    # Summary
    print("\n📊 Test Results Summary:")
    print("=" * 50)
    
    successful_logins = [r for r in results if r['success']]
    
    if successful_logins:
        print(f"\n✅ Successful logins ({len(successful_logins)}):")
        for result in successful_logins:
            print(f"  • {result['username']} on {result['url']}")
    else:
        print("\n❌ No successful logins found")
    
    failed_logins = [r for r in results if not r['success']]
    if failed_logins:
        print(f"\n❌ Failed logins ({len(failed_logins)}):")
        for result in failed_logins:
            print(f"  • {result['username']} on {result['url']}: {result['message']}")
    
    # Recommendations
    print("\n💡 Recommendations:")
    if not successful_logins:
        print("  1. Check if the database connection is working")
        print("  2. Verify user accounts exist in the database")
        print("  3. Check session configuration in config.php")
        print("  4. Ensure nginx is properly configured")
        print("  5. Check PHP error logs for detailed error messages")
    else:
        print("  1. Login functionality appears to be working")
        print("  2. Test additional user workflows (registration, password reset, etc.)")
        print("  3. Verify session persistence across page reloads")

if __name__ == "__main__":
    main()