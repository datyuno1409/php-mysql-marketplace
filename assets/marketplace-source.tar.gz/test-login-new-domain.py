#!/usr/bin/env python3
import requests
import sys
import urllib3

# Disable SSL warnings for testing
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def test_login(base_url, username, password):
    """Test login functionality"""
    session = requests.Session()
    
    try:
        # Get login page first
        login_url = f"{base_url}/login/"
        print(f"\n=== Testing login for {username} ===")
        print(f"Getting login page: {login_url}")
        
        response = session.get(login_url, verify=False, timeout=10)
        print(f"Login page status: {response.status_code}")
        
        if response.status_code != 200:
            print(f"❌ Failed to get login page: {response.status_code}")
            return False
            
        # Attempt login
        login_data = {
            'username': username,
            'password': password
        }
        
        print(f"Attempting login with username: {username}")
        login_response = session.post(login_url, data=login_data, verify=False, timeout=10)
        print(f"Login response status: {login_response.status_code}")
        
        # Check if redirected to main page (successful login)
        if login_response.status_code == 302 or 'Location' in login_response.headers:
            print(f"✅ Login successful - redirected")
            
            # Try to access protected page
            dashboard_response = session.get(base_url, verify=False, timeout=10)
            if 'logout' in dashboard_response.text.lower() or 'dashboard' in dashboard_response.text.lower():
                print(f"✅ Session maintained - can access protected content")
                return True
            else:
                print(f"⚠️ Login successful but session not maintained")
                return False
                
        elif 'welcome' in login_response.text.lower() or 'dashboard' in login_response.text.lower():
            print(f"✅ Login successful - content loaded")
            return True
        else:
            print(f"❌ Login failed - no redirect or welcome message")
            print(f"Response content preview: {login_response.text[:200]}...")
            return False
            
    except requests.exceptions.SSLError as e:
        print(f"❌ SSL Error: {e}")
        return False
    except requests.exceptions.ConnectionError as e:
        print(f"❌ Connection Error: {e}")
        return False
    except requests.exceptions.Timeout as e:
        print(f"❌ Timeout Error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def main():
    # Test both HTTP and HTTPS
    domains = [
        "https://vn-nextstep.cftenant.com",
        "http://vn-nextstep.cftenant.com",
        "http://103.9.205.28"  # Fallback to direct IP
    ]
    
    # Test accounts
    test_accounts = [
        {"username": "admin", "password": "admin123"},
        {"username": "seller1", "password": "seller123"},
        {"username": "user1", "password": "user123"},
        {"username": "testuser", "password": "test123"}
    ]
    
    print("🔍 Testing login functionality on new domain...")
    
    for domain in domains:
        print(f"\n{'='*50}")
        print(f"Testing domain: {domain}")
        print(f"{'='*50}")
        
        # First check if domain is accessible
        try:
            response = requests.get(domain, verify=False, timeout=10)
            print(f"Domain accessibility: {response.status_code}")
            
            if response.status_code != 200:
                print(f"❌ Domain not accessible, skipping...")
                continue
                
        except Exception as e:
            print(f"❌ Cannot access domain: {e}")
            continue
        
        # Test each account
        successful_logins = 0
        for account in test_accounts:
            if test_login(domain, account["username"], account["password"]):
                successful_logins += 1
        
        print(f"\n📊 Results for {domain}:")
        print(f"Successful logins: {successful_logins}/{len(test_accounts)}")
        
        if successful_logins > 0:
            print(f"✅ Domain {domain} is working!")
            break
        else:
            print(f"❌ No successful logins on {domain}")
    
    print("\n🏁 Test completed!")

if __name__ == "__main__":
    main()