#!/usr/bin/env python3
import requests

def test_login(username, password):
    """Test login with given credentials"""
    session = requests.Session()
    base_url = "http://localhost"
    
    try:
        # Get login page
        login_page = session.get(f"{base_url}/login/")
        if login_page.status_code != 200:
            return False, f"Cannot access login page: {login_page.status_code}"
        
        # Attempt login
        login_data = {
            'username': username,
            'password': password,
            'submit': 'Login'
        }
        
        response = session.post(f"{base_url}/login/", data=login_data, allow_redirects=False)
        
        if response.status_code == 302:
            redirect_url = response.headers.get('Location', '')
            
            # Handle relative URL
            if redirect_url.startswith('../'):
                redirect_path = redirect_url.replace('../', '/')
                final_url = f"{base_url}{redirect_path}"
            elif redirect_url.startswith('/'):
                final_url = f"{base_url}{redirect_url}"
            else:
                final_url = redirect_url
            
            # Follow redirect
            final_response = session.get(final_url)
            if final_response.status_code == 200:
                return True, f"Login successful, redirected to {redirect_url}"
            else:
                return False, f"Redirect failed: {final_response.status_code}"
        elif response.status_code == 200:
            # Check if still on login page
            content = response.text.lower()
            if "login" in content and "username" in content:
                return False, "Login failed - still on login page"
            else:
                return True, "Login successful - no redirect but content changed"
        else:
            return False, f"Login failed: {response.status_code}"
            
    except Exception as e:
        return False, f"Error: {str(e)}"

def main():
    print("=== Testing All Login Accounts ===")
    print()
    
    # Actual accounts from database
    accounts = [
        ('serein', 'Fpt1409!@', 'admin'),
        ('seller', 'Fpt1409!@', 'seller'),
        ('user', 'Fpt1409!@', 'user'),
        ('userAKA', 'Fpt1409!@', 'user')
    ]
    
    successful_logins = 0
    total_tests = len(accounts)
    
    for username, password, role in accounts:
        print(f"Testing {username} ({role})...")
        success, message = test_login(username, password)
        
        if success:
            print(f"   ✅ {message}")
            successful_logins += 1
        else:
            print(f"   ❌ {message}")
        print()
    
    print("=== SUMMARY ===")
    print(f"Successful logins: {successful_logins}/{total_tests}")
    print(f"Failed logins: {total_tests - successful_logins}/{total_tests}")
    print()
    
    if successful_logins == total_tests:
        print("🎉 All accounts can login successfully!")
        return True
    elif successful_logins > 0:
        print("⚠️  Some accounts can login, but not all")
        return False
    else:
        print("❌ No accounts can login - there may be an issue")
        return False

if __name__ == "__main__":
    success = main()
    print(f"\nOverall result: {'✅ SUCCESS' if success else '❌ FAILED'}")