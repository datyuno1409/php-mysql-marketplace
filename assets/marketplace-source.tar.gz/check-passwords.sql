SELECT username, password FROM accounts WHERE username = 'user';
