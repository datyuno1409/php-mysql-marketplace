#!/usr/bin/env python3
import requests

def test_manual_login():
    """Test login manually with detailed output"""
    session = requests.Session()
    base_url = "http://localhost"
    
    print("=== Manual Login Test ===")
    
    # Test with serein (admin)
    username = "serein"
    password = "Fpt1409!@"
    
    print(f"\n1. Getting login page...")
    login_page = session.get(f"{base_url}/login/")
    print(f"   Status: {login_page.status_code}")
    
    if login_page.status_code != 200:
        print("❌ Cannot access login page")
        return False
    
    print(f"\n2. Attempting login with {username}...")
    login_data = {
        'username': username,
        'password': password,
        'submit': 'Login'
    }
    
    # Don't follow redirects to see the actual response
    response = session.post(f"{base_url}/login/", data=login_data, allow_redirects=False)
    print(f"   Status: {response.status_code}")
    print(f"   Headers: {dict(response.headers)}")
    
    if response.status_code == 302:
        redirect_url = response.headers.get('Location', '')
        print(f"   ✅ Redirect to: {redirect_url}")
        
        # Follow the redirect
        print(f"\n3. Following redirect...")
        if redirect_url.startswith('../'):
            # Handle relative URL like ../admin/
            redirect_path = redirect_url.replace('../', '/')
            final_url = f"{base_url}{redirect_path}"
        elif redirect_url.startswith('/'):
            final_url = f"{base_url}{redirect_url}"
        else:
            final_url = redirect_url
            
        print(f"   Redirect URL: {final_url}")
        final_response = session.get(final_url)
        print(f"   Final status: {final_response.status_code}")
        print(f"   Final URL: {final_response.url}")
        
        if final_response.status_code == 200:
            print("   ✅ Login successful!")
            return True
    elif response.status_code == 200:
        print("   ⚠️ No redirect - checking response content...")
        content = response.text[:500]
        print(f"   Content preview: {content}")
        
        if "login" in content.lower() and "username" in content.lower():
            print("   ❌ Still on login page - login failed")
        else:
            print("   ✅ Login successful (no redirect but content changed)")
            return True
    
    print("   ❌ Login failed")
    return False

if __name__ == "__main__":
    success = test_manual_login()
    print(f"\n=== RESULT ===")
    print(f"Login test: {'✅ SUCCESS' if success else '❌ FAILED'}")