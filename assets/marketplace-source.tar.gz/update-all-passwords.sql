UPDATE accounts SET password = 'Fpt1409!@' WHERE username IN ('serein', 'seller', 'user', 'userAKA');
