<?php
// Test database connection
echo "Testing database connection...\n";

$servername = "localhost";
$username = "callmeserein";
$password = "Fpt1409!@";
$dbname = "marketplace";

echo "Connecting to: $servername\n";
echo "Username: $username\n";
echo "Database: $dbname\n";

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        echo "Connection failed: " . $conn->connect_error . "\n";
    } else {
        echo "Connected successfully!\n";
        
        // Test a simple query
        $result = $conn->query("SELECT COUNT(*) as count FROM users");
        if ($result) {
            $row = $result->fetch_assoc();
            echo "Users count: " . $row['count'] . "\n";
        } else {
            echo "Query failed: " . $conn->error . "\n";
        }
    }
    
    $conn->close();
} catch (Exception $e) {
    echo "Exception: " . $e->getMessage() . "\n";
}
?>