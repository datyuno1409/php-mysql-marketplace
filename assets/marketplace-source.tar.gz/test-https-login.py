#!/usr/bin/env python3
import requests
import sys
from urllib.parse import urljoin

def test_login(base_url, username, password):
    """Test login functionality"""
    session = requests.Session()
    
    try:
        # Get login page
        login_url = urljoin(base_url, '/login/')
        print(f"Testing login at: {login_url}")
        
        response = session.get(login_url, timeout=10)
        print(f"Login page status: {response.status_code}")
        
        if response.status_code != 200:
            print(f"❌ Cannot access login page: {response.status_code}")
            return False
            
        # Attempt login
        login_data = {
            'username': username,
            'password': password
        }
        
        response = session.post(login_url, data=login_data, timeout=10, allow_redirects=False)
        print(f"Login attempt status: {response.status_code}")
        
        if response.status_code == 302:
            redirect_location = response.headers.get('Location', '')
            print(f"✅ Login successful - redirected to: {redirect_location}")
            return True
        elif response.status_code == 200:
            if 'error' in response.text.lower() or 'invalid' in response.text.lower():
                print(f"❌ Login failed - invalid credentials")
            else:
                print(f"⚠️ Login response unclear - status 200 but no redirect")
            return False
        else:
            print(f"❌ Login failed - unexpected status: {response.status_code}")
            return False
            
    except requests.exceptions.RequestException as e:
        print(f"❌ Connection error: {e}")
        return False
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return False

def main():
    # Test accounts with correct password
    test_accounts = [
        ('serein', 'Fpt1409!@'),
        ('seller', 'Fpt1409!@'),
        ('user', 'Fpt1409!@'),
        ('userAKA', 'Fpt1409!@')
    ]
    
    base_url = 'https://vn-nextstep.cftenant.com'
    
    print(f"Testing login functionality on {base_url}")
    print("=" * 50)
    
    success_count = 0
    
    for username, password in test_accounts:
        print(f"\nTesting account: {username}")
        if test_login(base_url, username, password):
            success_count += 1
        print("-" * 30)
    
    print(f"\nSummary: {success_count}/{len(test_accounts)} accounts logged in successfully")
    
    if success_count > 0:
        print("✅ Login functionality is working!")
    else:
        print("❌ No accounts could log in - check credentials or system")

if __name__ == '__main__':
    main()