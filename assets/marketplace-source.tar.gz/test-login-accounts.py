#!/usr/bin/env python3
import requests
import sys

def test_login(username, password):
    """Test login with given credentials"""
    login_url = "http://localhost/login/"
    
    # First get the login page to establish session
    session = requests.Session()
    response = session.get("http://localhost")
    
    if response.status_code != 200:
        print(f"❌ Cannot access login page: {response.status_code}")
        return False
    
    # Attempt login
    login_data = {
        'username': username,
        'password': password
    }
    
    response = session.post(login_url, data=login_data, allow_redirects=False)
    
    if response.status_code == 302:  # Redirect indicates successful login
        print(f"✅ Login successful for {username}")
        return True
    elif "Invalid username or password" in response.text:
        print(f"❌ Login failed for {username}: Invalid credentials")
        return False
    else:
        print(f"⚠️  Login response for {username}: Status {response.status_code}")
        return False

def main():
    print("Testing login for all known accounts...\n")
    
    # Actual accounts from database (all use same password: Fpt1409!@)
    test_accounts = [
        ("serein", "Fpt1409!@"),   # admin role
        ("seller", "Fpt1409!@"),   # seller role
        ("user", "Fpt1409!@"),     # user role
        ("userAKA", "Fpt1409!@")   # user role
    ]
    
    successful_logins = 0
    total_tests = len(test_accounts)
    
    for username, password in test_accounts:
        if test_login(username, password):
            successful_logins += 1
        print()  # Empty line for readability
    
    print(f"\n=== SUMMARY ===")
    print(f"Successful logins: {successful_logins}/{total_tests}")
    print(f"Failed logins: {total_tests - successful_logins}/{total_tests}")
    
    if successful_logins == total_tests:
        print("🎉 All accounts can login successfully!")
    elif successful_logins > 0:
        print("⚠️  Some accounts can login, but not all")
    else:
        print("❌ No accounts can login - there may be an issue")

if __name__ == "__main__":
    main()