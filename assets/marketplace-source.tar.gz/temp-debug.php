<?php
session_start();
include 'config.php';
$query = new Database();

echo "<h1>Debug Simple Login Test</h1>";
echo "<p>Config loaded successfully</p>";

if (isset($_POST['submit'])) {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';
    
    echo "<p>Username: $username</p>";
    echo "<p>Password: $password</p>";
    echo "<p>Password check: " . ($password === 'Fpt1409!@' ? 'MATCH' : 'NO MATCH') . "</p>";
    
    if ($username && $password) {
        $user = $query->select('accounts', '*', "WHERE username = '$username'");
        echo "<p>User found: " . (($user && count($user) > 0) ? 'YES' : 'NO') . "</p>";
        
        if ($user && count($user) > 0) {
            $userData = $user[0];
            echo "<p>User role: " . $userData['role'] . "</p>";
            
            if ($password === 'Fpt1409!@') {
                echo "<p style='color: green;'>LOGIN SUCCESS!</p>";
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $userData['username'];
                $_SESSION['role'] = $userData['role'];
            } else {
                echo "<p style='color: red;'>PASSWORD MISMATCH</p>";
            }
        }
    }
}
?>

<form method="POST">
    <p>Username: <input type="text" name="username" value="serein"></p>
    <p>Password: <input type="password" name="password" value="Fpt1409!@"></p>
    <p><input type="submit" name="submit" value="Test Login"></p>
</form>

<?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin']): ?>
    <p style="color: green;">Session is active! Username: <?php echo $_SESSION['username']; ?></p>
<?php endif; ?>