#!/usr/bin/env python3
import requests
import urllib3
from urllib.parse import urljoin

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def test_debug_login():
    base_url = "http://103.9.205.28:8090"
    debug_url = urljoin(base_url, "/index.php")
    
    session = requests.Session()
    session.verify = False  # Skip SSL verification
    
    print(f"Testing main page at: {debug_url}")
    print("=" * 50)
    
    try:
        # First, get the debug page
        response = session.get(debug_url)
        print(f"Main page status: {response.status_code}")
        
        if response.status_code == 200:
            print("Debug page loaded successfully")
            print("Page content preview:")
            print(response.text[:500] + "..." if len(response.text) > 500 else response.text)
            
            # Now test the login form
            login_data = {
                'username': 'serein',
                'password': 'Fpt1409!@',
                'submit': 'Test Login'
            }
            
            print("\nTesting login form submission...")
            login_response = session.post(debug_url, data=login_data)
            print(f"Login response status: {login_response.status_code}")
            
            if login_response.status_code == 200:
                print("\nLogin response content:")
                print(login_response.text)
            else:
                print(f"Login failed with status: {login_response.status_code}")
        else:
            print(f"Failed to load main page: {response.status_code}")
            print(response.text[:500])
            
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    test_debug_login()
